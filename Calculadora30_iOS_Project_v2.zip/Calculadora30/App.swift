import SwiftUI

@main
struct Calculadora30App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
